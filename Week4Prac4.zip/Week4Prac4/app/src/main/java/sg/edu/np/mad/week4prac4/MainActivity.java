package sg.edu.np.mad.week4prac4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private String TAG = "Main Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button controlbutton = findViewById(R.id.followbutton);
        User myObj = new User();
        myObj.name = "MAD";
        myObj.description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
        Intent mIntent = getIntent();

        TextView hiworld = findViewById(R.id.hiworld);
        Intent myIntent = getIntent();
        Bundle extras = getIntent().getExtras();
        int randomno = extras.getInt("randomno");
        hiworld.setText("MAD" + randomno);
            //The key argument here must match that used in the other activity



        controlbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myObj.followed == true){
                    controlbutton.setText("UNFOLLOW");
                    Toast.makeText(getApplicationContext(), "Fed", Toast.LENGTH_SHORT).show();
                    Log.v(TAG, "followed toast");
                    myObj.setFollowed(false);
                }
                else{
                    controlbutton.setText("FOLLOW");
                    Toast.makeText(getApplicationContext(), "Und", Toast.LENGTH_SHORT).show();
                    Log.v(TAG, "unfollowed toast");
                    myObj.setFollowed(true);
                };
            }
        });
    }
}

